package com.example.courier

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    var base = "http://192.168.0.10:8080"

    data class Order(val id: Int, val title: String, val leftSec: Int, val done: Boolean)

    private fun call(method: String, path: String, body: JSONObject? = null): String {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 5000
        c.readTimeout = 5000
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun parse(o: JSONObject) =
        Order(o.getInt("id"), o.getString("title"), o.getInt("left_sec"), o.getBoolean("done"))

    suspend fun list(): List<Order> = withContext(Dispatchers.IO) {
        val a = JSONArray(call("GET", "/orders"))
        (0 until a.length()).map { parse(a.getJSONObject(it)) }
    }

    suspend fun get(id: Int): Order = withContext(Dispatchers.IO) {
        parse(JSONObject(call("GET", "/orders/$id")))
    }

    suspend fun create(title: String, minutes: Int): Order = withContext(Dispatchers.IO) {
        parse(JSONObject(call("POST", "/orders", JSONObject().put("title", title).put("minutes", minutes))))
    }

    suspend fun setEta(id: Int, minutes: Int) = withContext(Dispatchers.IO) {
        call("POST", "/orders/$id/eta", JSONObject().put("minutes", minutes))
    }

    suspend fun done(id: Int) = withContext(Dispatchers.IO) {
        call("POST", "/orders/$id/done", JSONObject())
    }
}

fun formatLeft(sec: Int): String {
    if (sec <= 0) return "курьер вот-вот будет"
    val total = (sec + 59) / 60
    val h = total / 60
    val m = total % 60
    return if (h > 0) "осталось ~$h ч $m мин" else "осталось ~$m мин"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var role by remember { mutableStateOf<String?>(null) }
    var url by remember { mutableStateOf(Api.base) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        when (role) {
            null -> {
                Text("Курьерская доставка", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; Api.base = it.trim().trimEnd('/') },
                    label = { Text("Адрес сервера") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = { role = "courier" }, Modifier.fillMaxWidth()) { Text("Я курьер") }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { role = "client" }, Modifier.fillMaxWidth()) { Text("Я клиент") }
            }
            "courier" -> CourierScreen { role = null }
            else -> ClientScreen { role = null }
        }
    }
}

@Composable
fun CourierScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var orders by remember { mutableStateOf(listOf<Api.Order>()) }
    var title by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("30") }
    var error by remember { mutableStateOf<String?>(null) }

    suspend fun refresh() {
        try {
            orders = Api.list().filter { !it.done }
            error = null
        } catch (e: Exception) {
            error = "Нет связи с сервером"
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            refresh()
            delay(5000)
        }
    }

    Column {
        TextButton(onClick = onBack) { Text("← Сменить роль") }
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Заказ / адрес") },
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.padding(vertical = 8.dp)) {
            OutlinedTextField(
                value = minutes,
                onValueChange = { minutes = it.filter(Char::isDigit) },
                label = { Text("Минут") },
                modifier = Modifier.width(110.dp)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                scope.launch {
                    try {
                        Api.create(title, minutes.toIntOrNull() ?: 30)
                        title = ""
                        refresh()
                    } catch (e: Exception) {
                        error = "Не удалось создать заказ"
                    }
                }
            }) { Text("Создать") }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        LazyColumn {
            items(orders) { o ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("№${o.id} · ${o.title}", style = MaterialTheme.typography.titleMedium)
                        Text(formatLeft(o.leftSec))
                        Row {
                            TextButton(onClick = {
                                scope.launch {
                                    runCatching { Api.setEta(o.id, o.leftSec / 60 + 10) }
                                    refresh()
                                }
                            }) { Text("+10 мин") }
                            TextButton(onClick = {
                                scope.launch {
                                    runCatching { Api.done(o.id) }
                                    refresh()
                                }
                            }) { Text("Доставлен") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClientScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var id by remember { mutableStateOf<Int?>(null) }
    var order by remember { mutableStateOf<Api.Order?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(id) {
        val cur = id ?: return@LaunchedEffect
        while (true) {
            try {
                order = Api.get(cur)
                error = null
            } catch (e: Exception) {
                error = "Заказ не найден или нет связи"
            }
            delay(5000)
        }
    }

    Column {
        TextButton(onClick = onBack) { Text("← Сменить роль") }
        Row {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it.filter(Char::isDigit) },
                label = { Text("Номер заказа") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { order = null; id = input.toIntOrNull() }) { Text("Отслеживать") }
        }
        Spacer(Modifier.height(16.dp))
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        order?.let { o ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Заказ №${o.id} · ${o.title}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (o.done) "Доставлен" else formatLeft(o.leftSec),
                        style = MaterialTheme.typography.headlineSmall
                    )
                }
            }
        }
    }
}
