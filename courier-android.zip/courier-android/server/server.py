"""Мини-сервер заказов для приложения. Запуск: python server.py (порт 8080)."""
import json
import re
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB = "orders_api.db"


def run(sql, args=()):
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    cur = con.execute(sql, args)
    rows = cur.fetchall()
    con.commit()
    last = cur.lastrowid
    con.close()
    return rows, last


def dto(r):
    return {
        "id": r["id"],
        "title": r["title"],
        "done": bool(r["done"]),
        "left_sec": max(0, int(r["eta"] - time.time())),
    }


class Handler(BaseHTTPRequestHandler):
    def reply(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def payload(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        m = re.fullmatch(r"/orders(?:/(\d+))?", self.path)
        if not m:
            return self.reply({"error": "not found"}, 404)
        if m.group(1):
            rows, _ = run("SELECT * FROM orders WHERE id=?", (m.group(1),))
            if not rows:
                return self.reply({"error": "not found"}, 404)
            return self.reply(dto(rows[0]))
        rows, _ = run("SELECT * FROM orders ORDER BY id DESC LIMIT 100")
        self.reply([dto(r) for r in rows])

    def do_POST(self):
        data = self.payload()
        if self.path == "/orders":
            eta = time.time() + int(data["minutes"]) * 60
            _, oid = run("INSERT INTO orders(title, eta) VALUES(?, ?)", (data["title"], eta))
            rows, _ = run("SELECT * FROM orders WHERE id=?", (oid,))
            return self.reply(dto(rows[0]), 201)
        m = re.fullmatch(r"/orders/(\d+)/(eta|done)", self.path)
        if not m:
            return self.reply({"error": "not found"}, 404)
        oid, action = m.groups()
        if action == "eta":
            run("UPDATE orders SET eta=? WHERE id=?", (time.time() + int(data["minutes"]) * 60, oid))
        else:
            run("UPDATE orders SET done=1 WHERE id=?", (oid,))
        self.reply({"ok": True})

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    run("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, eta REAL, done INTEGER DEFAULT 0)""")
    print("Сервер: http://0.0.0.0:8080")
    ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
