# Курьерское приложение (Android, Kotlin)

1. Сервер (на ПК или VPS): `cd server && python server.py`
2. APK: загрузите папку на GitHub -> вкладка Actions -> Build APK -> Artifacts -> courier-apk.
3. В приложении введите адрес сервера (например http://192.168.0.10:8080), выберите роль.
